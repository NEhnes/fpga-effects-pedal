---
name: fpga-pedal-axi-modules
description: Generates and designs Verilog DSP modules for a Zedboard guitar effects pedal using cycle-by-cycle AXI-Stream interconnects. Use when writing audio effects, managing backpressure propagation, or implementing synchronous gated state updates.
tags:
  - verilog
  - fpga
  - axi-stream
  - dsp
  - guitar-pedal
applies_to:
  - verilog module design
  - fpga effect blocks
  - axi-stream protocol
triggers:
  - writing effect modules for the pedal
  - designing axi-stream interconnect
  - understanding backpressure and state gating
---

# FPGA Guitar Pedal: AXI-Stream Module Design

## Core Architecture & Constraints

All modules must conform strictly to the hardware pipeline environment and the template provided in `references/axistream_template.v`.

* **Audio Format:** Mono, 24-bit signed samples (`WIDTH = 24`), ~48 kHz sample rate, clocked entirely by `tclk`.
* **No Buffering:** The entire pipeline is unbuffered. No internal FIFOs or queues. Backpressure propagates instantly cycle-by-cycle.

---

## Architectural Rules

### 1. The Handshake & Backpressure
Data transfers occur **only** on the clock edge where `i_tvalid && o_tready` is true.
* **Direct Coupling:** Unless timing closure forces a registered boundary, pass backpressure and valid signals straight through combinationally:
    ```verilog
    assign i_tready = o_tready;
    assign o_tvalid = i_tvalid;
    ```

### 2. Gated State Updates
**Every internal register and state variable** (pointers, RAM writes, multi-stage pipeline steps, accumulator states) must be strictly gated. They must only update when the downstream block is ready to receive data and the upstream block has valid data:
```verilog
always @(posedge tclk or negedge rst_n) begin
    if (!rst_n) begin
        // Synchronous active-low reset of ALL internal state registers and o_tdata
    end
    else if (i_tvalid && o_tready) begin
        // Perform combinational DSP math and latch into state/output registers here
    end
end

### 3. Makeup Gain
* **ANY effect that alters the volume of the signal must have a makeup gain stage at the very end, as per the axi_template.v file at ./references/axi_template.v**

---

## Completed Example

View the completed example for the fuzz pedal at ./references/fuzz_example.v. It is very well done and serves as Best Practices example.
