---
name: verilog-testbench
description: "Write Verilog testbenches following pure Verilog standards (no SystemVerilog) for icarus verilog environment. Designed to be modular in nature."
---

# Verilog Testbench Generator

Write testbenches for pure Verilog modules.

## Your Standards

- **Language**: Pure Verilog only (no SystemVerilog)
- **Simulator**: icarus verilog
- **Waveform Viewer**: GTKWave
- **Timescale**: `1ns / 1ps`
- **Reset**: Synchronous, active-low (`rst_n`)
- **Clock naming**: `clk`
- **Stimulus timing**: Apply inputs on `posedge clk`
- **Comment Verbosity**: Verbose, concise wording
- **Data types**: `reg`/`wire` only
- **Naming**: `snake_case` for signals
- **Testbench file**: `<module_name>_tb.v`
- **Test structure**: Separate `initial` blocks for modularity
- **Timeout**: Explicit `#<max_ns>` stop to prevent hang
- **Output**: Pass/fail summary to console + waveform dump

---

## Test Terminal Output

__all sections should be separated with whitespace & titles__
__all columns should be aligned and easily scannable__

- **Test Result**: Each test should output <test-name> [PASS/FAIL], if test fails, print relevant variables & comparison to terminal. It should also reference the test number so i can find it easily in code.
- **Result Summary**: At the end of test, a summary block should display total passes and fails & performance metrics (if applicable)
- **Failure Summary**: At the very end, the terminal should specify exactly which modules failed, and for each one, display the logged data and details of failure.

## Testbench Structure

- Mostly just comments to describe high-level organization
- Some example variables/code included to show my conventions

```verilog
`timescale 1ns / 1ps
`include '<module>.v'

module <module_name>_tb;

  // global clock and reset

  // dut signals (match module ports)

  // global test control variables
    integer num_pass, num_fail;

  // per-test control
    integer <test-name>_counter;

  // Instantiate DUT

  // Clock generation
  initial begin
    clk = 1'b0;
    forever #5 clk = ~clk;  // 10ns period
  end

  // Test sequence
  initial begin

    // instantiate variables as needed

    reset;

    <test1-name>;

    reset;

    <test2-name>

    // . . .
  end

  task reset;
  begin
    rst_n = 1'b0;
    // other reset-time signals (data, handshake signals, etc.)
    #50;
    rst_n = 1'b1;
  end
  endtask

  //  ======= TEST 1 =======
  task <task1-name>;
  begin
    // Wait for reset to complete
    wait(rst_n == 1'b1);

    #10;  // Wait one more clock edge

    // Stimulus
    @(posedge clk) input_signal = 8'hAB;
    @(posedge clk) input_signal = 8'h00;

    // Check output
    @(posedge clk);
    if (output_signal == 8'hCD) begin
      $display("[PASS] Test case 1");
      num_pass = num_pass + 1;
    end else begin
      $display("[FAIL] Test case 1: expected 8'hCD, got %h", output_signal);
      num_fail = num_fail + 1;
    end
  end
  endtask

  // Timeout
  initial begin
    #10000;  // 10µs max simulation time
    $display("\n=== Test Summary ===");
    $display("Passed: %d", num_pass);
    $display("Failed: %d", num_fail);
    $finish;
  end

  // Waveform dump
  initial begin
    $dumpfile("<module_name>_tb.vcd");
    $dumpvars(0, <module_name>_tb);
  end

endmodule
```

---

## Key Patterns

### Synchronize to clock
```verilog
@(posedge clk) signal = value;  // Sample next cycle
@(negedge clk) signal = value;  // Opposite edge
```

### Wait for condition
```verilog
wait(condition == 1'b1);  // Block until true
```

### Check with tolerance (for data, when fixed point error involved)
```verilog
if (output >= expected - 1 && output <= expected + 1) begin
  // Pass
end
```

### Multiple tests in sequence
Create separate `task` blocks; they run simultaneously:
```verilog
task <task1-name>;
begin
  // body goes here
end
endtask
```

---

## When You Have the Module Source

Share your Verilog module, and I will:

1. Extract port list and signal widths
2. Map stimulus to inputs based on function
3. Predict outputs and add checks
4. Create separate test cases for edge cases
5. Add timing comments for clarity
6. Verify clock/reset alignment

Then you review, adjust assertions, and simulate.

---

## Mandatory Test Coverage

Every testbench **must** cover these categories. Pick only the ones relevant to the module under test — don't pad with meaningless tests. Each test should have a clear pass/fail criterion with console output.

### Infrastructure Tests (ALL modules with AXI-Stream)

- **Reset clears state**: Verify `o_tdata`, `o_tvalid`, and all internal state registers return to zero after `rst_n` assertion and de-assertion.
- **AXI handshake**: Verify `o_tvalid` asserts when data is valid and `i_tready` asserts when module can accept (`@(posedge clk)` after applying stimulus).
- **Backpressure**: Assert `o_tready=0` and confirm `i_tready=0` propagates upstream. Then release (`o_tready=1`) and confirm `i_tready` re-asserts.
- **Zero input**: Drive all-zero input data and confirm output is also zero (detects bias, offset, or uninitialized state).

### Effect-Specific Tests (for audio effect modules like fuzz, delay, flanger, clip)

- **Unity passthrough**: Apply unity gain / bypass parameters and verify output equals input (within fixed-point tolerance).
- **Gain amplification**: At least one non-unity gain value (e.g. 2x) with a tolerance band for fixed-point rounding.
- **Positive clipping**: Input exceeds threshold; verify output clamps at (or near) the positive threshold value.
- **Negative clipping**: Input below negative threshold; verify output clamps at (or near) the negative threshold value.
- **Zero threshold**: Set threshold to 0 and confirm output clamps to zero (or behaves as specified for that edge case).
- **Saturation / overflow clamping**: Drive values that cause arithmetic overflow in internal sums/products; confirm output saturates at MAX_POS / MAX_NEG rather than wrapping.
- **Min/max parameter edges**: Test with extreme parameter values — e.g. `pre_gain=16'h7FFF`, `tone_coeff=8'd255`, `feedback=16'd32767`, min delay, max depth. Do not assume parameters operate linearly at extremes.
- **Constrained random parameter variation** (≥3 combos): Run the same input through at least 3 different random parameter sets (use `$random` seeded with a constant). For each combo, verify output stays within valid range, does not saturate unexpectedly, and produces different output (i.e. parameters actually affect the signal).
- **Gain + clip interaction**: Verify that gain can push a below-threshold signal into clipping, and that a below-clip signal with the same threshold stays clean — confirms pipeline ordering is correct.
- **DC step / pipeline settling**: Apply a constant input and verify the output stabilizes at the expected value within the pipeline depth + margin. Catches off-by-one latency or state-retention bugs.

### What NOT to Test (waste of time)

- Assert that an unconnected wire is high-Z (Verilog doesn't model this usefully in simulation)
- Test timing closure (that's for static timing analysis, not simulation)
- Test every single bit pattern exhaustively for wide buses (use constrained random instead)
- Test that obvious combinational logic produces the correct truth table (test the module that *uses* it instead)
